document.getElementById("myBtn").addEventListener("click", myFunction);


function myFunction() {
let data = [{
        player: "Jane",
        score: 52
    }, 
    {
        player: "Mark",
        score: 41
    }
     
]


document.getElementById("demo").innerHTML =data[0].score;
}